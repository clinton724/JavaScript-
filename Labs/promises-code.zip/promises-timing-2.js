'use strict'

Promise.resolve(5)
  .then(n => {
    console.log('First callback for resolved promise')
    return n * 2
  })
  .then(n => {
    console.log('Second callback for resolved promise')
    return n + 1
  })
  .then(n => n.toString())
  .then(n => console.log(n))

Promise.reject(new Error('Rejected'))
.catch(e => console.log(e.message))
