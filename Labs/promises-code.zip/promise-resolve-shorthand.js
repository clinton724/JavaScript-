'use strict'

Promise.resolve(5)
  .then(n => n * 2)
  .then(n => n + 1)
  .then(n => n.toString())
  .then(n => console.log(n))

// Output: 11
