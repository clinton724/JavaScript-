'use strict'

const delay = function (ms) {
  return new Promise(resolve => setTimeout(resolve, ms)) // cannot be rejected
}

delay(2000)
  .then(() => {
    console.log('Resolved after 2 seconds')
    return delay(1500)
  })
  .then(() => {
    console.log('Resolved after 1.5 seconds')
    throw new Error() // equivalent to: reject()
  })
  .catch(() => console.log('Caught an error'))
  .then(() => console.log('Done'))
