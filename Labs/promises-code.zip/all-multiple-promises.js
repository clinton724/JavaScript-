'use strict'

function getUser (id) {
  const users = [
    { id: 1, name: 'Joel' },
    { id: 2, name: 'Carla' },
    { id: 3, name: 'Tsholofelo' }
  ]
  const user = users.find(user => user.id === id)
  return new Promise(resolve => resolve(user))
}

Promise.all([getUser(2), getUser(3)])
  .then(users => {
    const usernames = users.map(user => user.name)
    console.log(usernames)
  })
// Output: [ 'Carla', 'Tsholofelo' ]
