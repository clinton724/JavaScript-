'use strict'

const array = []
array.push('before')

Promise.resolve().then(() => {
  array.push('then')
})

array.push('after')

console.log(array)

Promise.resolve().then(() => console.log(array))
// Output: ['before', 'after', 'then']
