'use strict'

function itemList () {
  let items = []
  let i = 0
  while (i < 10) {
    let item = function () {
      console.log(i) // should show its number
    }
    items.push(item)
    i++
  }

  return items
}

let list = itemList()

// all items should show their position in the array:  0, 1, 2, 3
list[0]()
list[1]()
list[2]()
// ..
list[9]()

// why does this not work, and how do you correct it?
